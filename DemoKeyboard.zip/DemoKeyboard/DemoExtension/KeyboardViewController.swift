//
//  KeyboardViewController.swift
//  DemoExtension
//
//  Created by Milan on 27/08/21.
//  Copyright © 2021 Milan. All rights reserved.
//

import UIKit
import ISEmojiView
import BBPortal
import CCHDarwinNotificationCenter

var proxy : UITextDocumentProxy!

enum ScreenMode {
    case portrait
    case landspace
}

class KeyboardViewController: UIInputViewController
{
    
    
    @IBOutlet weak var keysView: UIView!
    @IBOutlet weak var suggestionBarContainerView: UIView!
    @IBOutlet weak var bgOfTheme: UIImageView!
    @IBOutlet var nextKeyboardButton: UIButton!
    @IBOutlet weak var stackView1: UIStackView!
    @IBOutlet weak var stackView2: UIStackView!
    @IBOutlet weak var stackView3: UIStackView!
    @IBOutlet weak var stackView4: UIStackView!
    
    
    var keyboardView: UIView!
    var keys: [KeyboardButton] = []
    var spaceKey:KeyboardButton?;
    var paddingViews: [UIButton] = []
    var backspaceTimer: Timer?
    
    var keyboardState: KeyboardState = .letters
    var shiftButtonState:ShiftButtonState = .normal;
    
    var screenOrientation: ScreenMode = .portrait
    
    //MARK: - Communication with  containing App
    var themeChangePortal: BBPortalProtocol?
    var bgBrighnessChangePortal:BBPortalProtocol?
    var makeDesignedKeyboardPortal:BBPortalProtocol?
    var keysColourChangePortal:BBPortalProtocol?;
    var viewThemePortal:BBPortalProtocol?;
    var userCreatedThemePortal:BBPortalProtocol?;
    var selectKeyboardFromKeyboardListPortal:BBPortalProtocol?
    
    //    var popup: KeyboardKeyBackground?
    
    var popUpView = UIView()
    
    // MARK: - Autocomplete
    lazy var autocompleteProvider = DemoAutocompleteSuggestionProvider();
    
    var suggestionList = [String]();
    @IBOutlet weak var suggestionTextCollectionView: UICollectionView!
    
    
    //MARK: - audio
    var audioConfiguration = AudioFeedbackConfiguration.standard;
    let hapticConfiguration =  HapticFeedbackConfiguration.standard
    
    // MARK:- constraints
    var portraitHeight:CGFloat = BasicMethod.device_IS_IPAD() ? 350 : 250.0;
    //    var portraitHeight:CGFloat = 350;
    
    let landscapeHeight:CGFloat = 500.0
    var heightConstraint: NSLayoutConstraint = NSLayoutConstraint();
    
    //MARK: - emoji view Delegate
    @IBOutlet weak var emojiView: EmojiView!{
        didSet
        {
            emojiView.delegate = self
            
        }
    }
    //MARK: - view did load
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.setupAllNotificationPortal()
        print("\n\n\nview did load\n\n\n"); self.inputView?.allowsSelfSizing = true
        proxy = textDocumentProxy as UITextDocumentProxy
        //set keyboard height
        self.setupUI()
        self.nextKeyboardClick()
    }
    
    
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        let screen = UIScreen.main.bounds
        if screen.width < screen.height {
            
            screenOrientation = .portrait
            suggestionTextCollectionView.reloadData()
            loadKeys()
            print("!!! portrait")
        } else {
            screenOrientation = .landspace
            suggestionTextCollectionView.reloadData()
            loadKeys()
            print("!!! landspace")
        }
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
        
        loadKeys()
        print("load all keys")
        self.setupSuggestionColectionView()
        
        UIPasteboard.general.string = Constants.defaultsKey.isSelectKeyboard
        
        Constants.appGroupDefaults?.set(self.isAllowFullAccess(), forKey: Constants.defaultsKey.isAllowFullAccess)
        Constants.appGroupDefaults?.synchronize()
        if let isSet = Constants.appGroupDefaults?.bool(forKey:Constants.defaultsKey.isSelectKeyboard)
        {
            
            if(!isSet)
            {
                Constants.appGroupDefaults?.set(true, forKey: Constants.defaultsKey.isSelectKeyboard);
                Constants.appGroupDefaults?.synchronize();
                self.openURL(url: NSURL(string: "customKeyboardExample://?backgroundColor=\(isAllowFullAccess())")!)
            }
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        Constants.appGroupDefaults?.set(self.isAllowFullAccess(), forKey: Constants.defaultsKey.isAllowFullAccess);
        Constants.appGroupDefaults?.synchronize();
        if let isSet = Constants.appGroupDefaults?.bool(forKey:Constants.defaultsKey.isAllowFullAccess)
        {
            
            
            if(Constants.appGroupDefaults!.bool(forKey: Constants.defaultsKey.isViewTheme))
            {
                print("..........will show\n\n\n\n\n\n\\n\n\n\n\n")
                DispatchQueue.main.async
                    {
                        if let fileManager = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.GroupID)
                        {
                            
                            let imageLocationUrl = fileManager.appendingPathComponent("viewTheme")
                            // for getting image
                            do {
                                let data:Data = try Data(contentsOf: imageLocationUrl);
                                let image = UIImage(data: data, scale: UIScreen.main.scale)
                                self.bgOfTheme.image  = image
                                self.bgOfTheme.contentMode = .scaleToFill;
                                for i in 0 ..< self.keys.count
                                {
                                    self.keys[i].bgImage.alpha = 0.7;
                                    
                                    self.keys[i].changeTheme(postfix: "_dark");
                                    
                                }
                                
                                if let spacekkey = self.spaceKey
                                {
                                    
                                    spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)_dark") ;
                                    
                                }
                                
                            }catch {
                                print("\n\nnot get data \n\n")
                                
                            }
                        }
                }
                
            }
            else
            {
                if(Constants.appGroupDefaults!.bool(forKey: Constants.defaultsKey.isSelectedUserCreatedTheme) )
                {
                    self.intiallySetCustomTheme();
                }
                else
                {
                    self.setupOnlineTheme();
                }
            }
            
            
            
            
        }
    }
    
    override func viewWillLayoutSubviews()
    {
        super.viewWillLayoutSubviews()
        self.nextKeyboardButton.superview?.isHidden = !self.needsInputModeSwitchKey
        self.nextKeyboardButton.isHidden = !self.needsInputModeSwitchKey
        
    }
    //    override func viewDidLayoutSubviews()
    //    {
    //
    //        if(UIScreen.main.bounds.size.width < UIScreen.main.bounds.size.height)
    //        {
    //            print("portrait");
    //
    //        }
    //        else
    //        {
    //            print("landscape");
    //        }
    //
    //    }
    //    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
    //    {
    //         super.viewWillTransition(to: size, with: coordinator)
    //
    //    }
    //    override func updateViewConstraints()
    //    {
    //        super.updateViewConstraints()
    //
    //
    //    }
    
    //MARK: - set up UI
    
    func setupUI()
    {
        self.setupCustomHeightOfKeyboard();
        self.loadInterfaceFromXIB();
    }
    
    func isAllowFullAccess() -> Bool
    {
        
        var hasFullAccess = false
        if #available(iOSApplicationExtension 10.0, *) {
            let pasty = UIPasteboard.general
            if pasty.hasURLs || pasty.hasColors || pasty.hasStrings || pasty.hasImages {
                hasFullAccess = true
            } else {
                pasty.string = "TEST"
                if pasty.hasStrings {
                    hasFullAccess = true
                    pasty.string = ""
                }
            }
        }
        else {
            // Fallback on earlier versions
            var clippy : UIPasteboard?
            clippy = UIPasteboard.general
            if clippy != nil {
                hasFullAccess = true
            }
        }
        return hasFullAccess;
    }
    
    //    override func willTransition(to newCollection: UITraitCollection, with coordinator: UIViewControllerTransitionCoordinator) {
    //
    //    }
    
    func changeKeyboardToNumberKeys()
    {
        keyboardState = .numbers
        shiftButtonState = .normal
        loadKeys()
    }
    
    func changeKeyboardToLetterKeys()
    {
        keyboardState = .letters
        loadKeys()
    }
    
    func changeKeyboardToSymbolKeys()
    {
        keyboardState = .symbols
        loadKeys()
    }
    
    func handlDeleteButtonPressed(){
        
        proxy.deleteBackward()
        requestAutocompleteSuggestions()
        self.hapticConfiguration.longPressFeedback.trigger()
        self.audioConfiguration.systemFeedback.trigger();
        
    }
    
    func nextKeyboardClick() {
        if #available(iOSApplicationExtension 10.0, *) {
            nextKeyboardButton.addTarget(self, action: #selector(handleInputModeList(from:with:)), for: .allTouchEvents)
        } else {
            // Fallback on earlier versions
            nextKeyboardButton.addTarget(self, action: #selector(advanceToNextInputMode), for: .touchUpInside)
        }
    }
    
    @objc func colorDidChangeToBlue(_ notification:Notification) {
        // Do something now
        print("\n\nhello kitty\n\n\n");
    }
    
    @objc func keyPressedTouchUp(_ sender: UIButton)
    {
        
        
        popUpView.removeFromSuperview()
        
        print("\n\n")
        print("nice...")
        print("\n\n")
        guard let originalKey = sender.layer.value(forKey: "original") as? String, let keyToDisplay = sender.titleLabel?.text else {return}
        
        guard let isSpecial = sender.layer.value(forKey: "isSpecial") as? Bool else {return}
        sender.backgroundColor = isSpecial ? Constants.specialKeyNormalColour : Constants.keyNormalColour
        
        switch originalKey {
        case keyType.backSpace.rawValue:
            if shiftButtonState == .shift {
                shiftButtonState = .normal
                loadKeys()
            }
            handlDeleteButtonPressed()
        case keyType.empoji.rawValue:
            self.emojiView.isHidden = false
            self.suggestionBarContainerView.isHidden = true;
            self.keysView.isHidden = true;
            
        case keyType.space.rawValue:
            
            proxy.insertText(" ")
            resetAutocompleteSuggestions();
            
        case keyType.browser.rawValue:
            nextKeyboardClick()
            break
        case keyType.newLine.rawValue:
            
            proxy.insertText("\n");
            resetAutocompleteSuggestions();
        case "123":
            changeKeyboardToNumberKeys()
        case "ABC":
            changeKeyboardToLetterKeys()
        case "#+=":
            changeKeyboardToSymbolKeys()
        case keyType.shift.rawValue:
            shiftButtonState = shiftButtonState == .normal ? .shift : .normal
            loadKeys();
        default:
            if shiftButtonState == .shift {
                shiftButtonState = .normal
                loadKeys()
            }
            proxy.insertText(keyToDisplay);
            requestAutocompleteSuggestions()
            
        }
        
        
        
        //        self.addPopup(to: sender)
    }
    
    //    func addPopup(to button: UIButton) {
    //        var frame: CGRect
    //        var frame1: CGRect
    //        if view.frame.size.width == 320 {
    //            //Keyboard is in Portrait
    //            frame = CGRect(x: 0, y: -25, width: 28, height: 43)
    //            frame1 = CGRect(x: 0, y: 0, width: 28, height: 43)
    //        } else {
    //            //Keyboard is in Landscape
    //            frame = CGRect(x: 3, y: -25, width: 35, height: 43)
    //            frame1 = CGRect(x: 0, y: 10, width: 35, height: 43)
    //        }
    //
    //
    //        let popUp = UIView(frame: frame)
    //        let text = UILabel()
    //        text.frame = frame1
    //        text.text = button.titleLabel?.text
    //        text.textAlignment = .center
    //        text.font = UIFont.boldSystemFont(ofSize: 30)
    //        text.backgroundColor = UIColor.white
    //
    //        //add label as popup view's subview
    //        popUp.addSubview(text)
    //
    //        //add pop up view as button's subview
    //        button.addSubview(popUp)
    
    //
    //            button.layer.zPosition = 1000
    //
    //            let popup = KeyboardKeyBackground(cornerRadius: 9.0, underOffset: 30)
    //            self.popup = popup
    //            button.addSubview(popup)
    //
    //            let popupLabel = UILabel()
    //            popupLabel.textAlignment = .center
    //            popupLabel.baselineAdjustment = .alignCenters
    //            popupLabel.font = UIFont.boldSystemFont(ofSize: 22)
    ////            popupLabel.adjustsFontSizeToFitWidth = true
    //            popupLabel.minimumScaleFactor = CGFloat(0.1)
    //            popupLabel.isUserInteractionEnabled = false
    //            popupLabel.numberOfLines = 1
    //            popupLabel.frame = popup.bounds
    //            popupLabel.text = button.titleLabel?.text
    //            popup.addSubview(popupLabel)
    ////            self.popupLabel = popupLabel
    ////
    ////            self.label.isHidden = true
    //
    //
    //
    //    }
    
    
    //MARK: - key press event
    @objc func keyMultiPress(_ sender: UIButton, event: UIEvent)
    {
        guard let originalKey = sender.layer.value(forKey: "original") as? String else {return}
        
        let touch: UITouch = event.allTouches!.first!
        if (touch.tapCount == 2 && originalKey == keyType.shift.rawValue)
        {
            shiftButtonState = .caps
            loadKeys()
        }
    }
    
    @objc func keyLongPressed(_ gesture: UIGestureRecognizer){
        if gesture.state == .began
        {
            backspaceTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (timer) in
                self.handlDeleteButtonPressed()
                guard let superview = (gesture.view as! UIButton).superview
                    else
                {
                    print("Error! `superview` was nil – call `addSubview(view: UIView)` before calling `bindFrameToSuperviewBounds()` to fix this.");
                    return;
                }
                
                superview.animateStandardTap();
            }
        } else if gesture.state == .ended || gesture.state == .cancelled {
            backspaceTimer?.invalidate()
            backspaceTimer = nil
            (gesture.view as! UIButton).backgroundColor = Constants.specialKeyNormalColour
        }
    }
    
    @objc func keyUntouched(_ sender: UIButton)
    {
        guard let isSpecial = sender.layer.value(forKey: "isSpecial") as? Bool else {return}
        sender.backgroundColor = isSpecial ? Constants.specialKeyNormalColour : Constants.keyNormalColour
    }
    
    @objc func keyTouchDown(_ sender: UIButton)
    {
        guard let superview = sender.superview
            else
        {
            print("Error! `superview` was nil – call `addSubview(view: UIView)` before calling `bindFrameToSuperviewBounds()` to fix this.");
            return;
        }
        
        superview.animateStandardTap();
        self.hapticConfiguration.tapFeedback.trigger()
        self.audioConfiguration.systemFeedback.trigger();
    }
    
    //MARK: - open setting
    //    func openSettingsOfApp()
    //    {
    //
    //        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
    //                  if let appSettings = URL(string: UIApplication.openSettingsURLString + Bundle.main.bundleIdentifier!) {
    //                         if UIApplication.shared.canOpenURL(appSettings) {
    //                         UIApplication.shared.open(appSettings)
    //                         }
    //                       }
    //        }
    //    }
    
    //MARK: - Button click
    override func textWillChange(_ textInput: UITextInput?)
    {
        // The app is about to change the document's contents. Perform any preparation here.
    }
    
    override func textDidChange(_ textInput: UITextInput?)
    {
        super.textDidChange(textInput)
        requestAutocompleteSuggestions();
        
        var textColor: UIColor
        let proxy = self.textDocumentProxy
        if proxy.keyboardAppearance == UIKeyboardAppearance.dark {
            textColor = UIColor.white
        } else {
            textColor = UIColor.black
        }
        self.nextKeyboardButton.setTitleColor(textColor, for: [])
    }
    
    override func selectionWillChange(_ textInput: UITextInput?) {
        super.selectionWillChange(textInput)
        //  autocompleteToolbar.reset()
        self.suggestionList.removeAll();
        self.suggestionTextCollectionView.reloadData();
    }
    
    override func selectionDidChange(_ textInput: UITextInput?)
    {
        super.selectionDidChange(textInput)
        // autocompleteToolbar.reset();
        self.suggestionList.removeAll();
        self.suggestionTextCollectionView.reloadData();
    }
    
    
}
