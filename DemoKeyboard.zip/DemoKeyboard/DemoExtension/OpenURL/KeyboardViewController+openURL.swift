//
//  KeyboardViewController+openURL.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 06/05/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit
extension KeyboardViewController
{
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool
    {
        
        print("Response From SourceApp=======>\(url.absoluteString)")
        
        return true
    }
    
    func opencibtext(str:String)
    {
        let url = NSURL(string:str)
        let context = NSExtensionContext()
        print(context.inputItems)
        context.open(url! as URL, completionHandler: nil)
        
        var responder = self as UIResponder?
        
        while (responder != nil){
            if responder?.responds(to: Selector("openURL:")) == true{
                responder?.perform(Selector("openURL:"), with: url)
            }
            responder = responder!.next
        }
    }
    
    func openURL(url: NSURL) -> Bool
    {
        
        do
        {
            let application:UIApplication = try self.sharedApplication();
            
            return application.performSelector(inBackground: "openURL:", with: url) != nil;
            
        }
        catch
        {
            return false
        }
    }
    
    func externalURLScheme() -> String? {
        guard let urlTypes =  Bundle.main.infoDictionary?["CFBundleURLTypes"] as? [AnyObject],
            let urlTypeDictionary = urlTypes.first as? [String: AnyObject],
            let urlSchemes = urlTypeDictionary["CFBundleURLSchemes"] as? [AnyObject],
            let externalURLScheme = urlSchemes.first as? String else { return nil }
        
        return externalURLScheme
    }
    
    func sharedApplication() throws -> UIApplication
    {
        
        var responder: UIResponder? = self
        while responder != nil
        {
            
            if let application = responder as? UIApplication
            {
                return application
            }
            
            responder = responder?.next
        }
        
        throw NSError(domain: "UIInputViewController+sharedApplication.swift", code: 1, userInfo: nil);
    }
    
}
