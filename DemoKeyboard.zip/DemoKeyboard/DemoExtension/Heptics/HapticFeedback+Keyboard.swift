//
//  HapticFeedback+Keyboard.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 04/07/20.
//  Copyright © 2020 Milan. All rights reserved.
//



import Foundation

public extension HapticFeedback {

    /**
     The standard haptic feedback for a button tap.
     */
    static var standardTapFeedback: HapticFeedback
    {
        .mediumImpact
    }
    
    /**
     The standard haptic feedback for a button long press.
    */
    static var standardLongPressFeedback: HapticFeedback {
        .heavyImpact
    }
}
