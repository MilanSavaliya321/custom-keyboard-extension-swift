//
//  DemoAutocompleteSuggestionProvider.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 20/04/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit
class DemoAutocompleteSuggestionProvider: AutocompleteSuggestionProvider
{
    func autocompleteSuggestions(for text: String, completion: AutocompleteResponse)
    {
        
        guard text.count > 0 else
        { return completion(.success([])) }
        
        let checkers = UITextChecker().completions(
            forPartialWordRange: NSRange(0..<text.utf16.count),
            in: text,
            language: "en_US"
        );
        var suffixes = ["ly", "er", "ter"]
        suffixes.removeAll();
        
        if let checkers = checkers
        {
            if(checkers.count != 0)
            {
                for i in 0..<3
                {
                    if(checkers.count > i)
                    {
                        suffixes.append(checkers[i])
                    }
                }
                let suggestions = suffixes.map { $0 }
                completion(.success(suggestions));
            }
            else
            {
                suffixes = [" "]
                let suggestions = suffixes.map { text + $0 }
                completion(.success(suggestions))
            }
            
        }
        
        
        //
        
        
    }
    
    @available(*, deprecated, renamed: "autocompleteSuggestions(for:completion:)")
    func provideAutocompleteSuggestions(for text: String, completion: AutocompleteResponse) {
        autocompleteSuggestions(for: text, completion: completion)
    }
}
