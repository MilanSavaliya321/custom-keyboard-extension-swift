//
//  Constants.swift
//
//  Created by Milan on 10/07/2019.
//  Copyright © 2019 Milan. All rights reserved.
//

import Foundation
import UIKit


public enum keyType:String,CaseIterable
{
    case shift = "⬆️"
    case doubleShift = "⏫"
    case empoji = "🐼"
    case newLine = "↩"
    case backSpace = "⌫"
    case space = "space"
    case browser = "🌐"
    case Captilized = "ABC"
    case numberised = "123"
    case symbolised = "#+="
}

class Constants
{
    
    //ARK: - prefix of img
    static let spaceImgPrefix = "spaceBtn_theme"
    static let specialImgPrefix = "specialKeyBtn_theme"
    static let btnImgPrefix = "btn_theme"
    static let designbgImgPrefix = "designbgImgPrefix"
    static let designKeyboardPrefix = "designKeyboardPrefix"
    static let bgPrefix = "bg_theme"
    static let emojiPrefix = "emojiPrefix"
    static let deleteImgPrefix = "deleteImgPrefix"
    static let newLineimgPrefix = "newLineimgPrefix"
    static let ShiftKeyPrefix = "ShiftKeyPrefix"
    static let lockedKeyPrefix = "lockedKeyPrefix"
    
    
    //MARK: - keys
    
    static let GroupID = " group.com.cbdash.ikeyboard "//"group.com.astha.keyboard"
    static var appGroupDefaults = UserDefaults(suiteName:GroupID);
    //"group.com.astha.keyboard";
    
    
    static var keyboardTheme:Int = 1;
    static var designTheme:Int = 0
    static let keyNormalColour: UIColor = .clear//.white
    static let keyPressedColour: UIColor = .lightText
    static let specialKeyNormalColour: UIColor = .clear//.gray
    static var keyFontColor:UIColor = .white
    
    public struct portalID
    {
        static let ThemeChange = "ThemeChange";
        static let bgBrightnessCahnge = "bgBrightnessCahnge";
        static let SetKeysColour = "SetKeysColour";
        static let selectKeyboardFromKeyboardList = "selectKeyboardFromKeyboardList";
        static let  viewTheme = "viewTheme";
        static let userCreatedThemeChange = "userCreatedThemeChange";
        static let makeDesignedKeyboard = "makeDesignedKeyboard";
    }
    
    public struct noOf
    {
        static var onlineTheme = 4;
        static var designedTheme = 0;
    }
    
    public struct cellID
    {
        static let suggestionTextCollectionCell =  "SuggestionTextCollectionViewCell";
        static let clipboardTextCell =  "clipboardTextCell";
        static let photosAlbumCell =  "photosAlbumCell";
        static let photosCell =  "photosCell";
    }
    
    public struct defaultsKey
    {
        static let clipboardWords =  "clipboardWords";
        static let customThemeImg =  "customThemeImg";
        static let isSetupCustomTheme = "isSetupCustomTheme";
        static let isSelectKeyboard = "isSelectKeyboard";
        static let isAllowFullAccess = "isAllowFullAccess";
        //   static let noofDesignTheme = "noofDesignTheme";
        static let brightnessOfDesignTheme = "brightnessOfDesignTheme";
        static let DesignedThemeList = "DesignedThemeList";
        
        
        static let onlineThemeNo = "onlineThemeNo";
        static let UserCreatedThemeNo = "designedThemeNo";
        static let isSelectedUserCreatedTheme = "isSelectedDesignedTheme";
        static let isViewTheme = "isViewTheme";
        static let noOfUserCreatedTheme = "noOfUserCreatedTheme";
        static let IS_IPad = "IS_IPad"
        static let onlineThemeFontColorPrefix = "onlineThemeFontColorPrefix";
        
        //MARK: - settings constants
        static let IS_soundOn = "Is_soundOn";
        static let IS_HepticOn = "IS_HepticOn";
        
        
    }
    
    public struct Device
    {
        static var type = UIUserInterfaceIdiom.phone
        static let IS_IPAD : Bool  = Constants.Device.type == .pad ? true : false;
    }
    
    public enum UIUserInterfaceIdiom : String
    {
        case unspecified  = "unspecified"
        case phone  = "iphone"
        case pad = "ipad"
        
        func type() -> String
        {
            return self.rawValue
        }
    }
    
    static let letterKeys = [
        ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
        ["a", "s", "d", "f", "g","h", "j", "k", "l"],
        ["⬆️", "z", "x", "c", "v", "b", "n", "m", "⌫"],
        ["123", "🌐","🐼","space", "↩"]
    ]
    
    static let numberKeys = [
        ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0",],
        ["-", "/", ":", ";", "(", ")" , "$", "&", "@", "\""],
        ["#+=",".", ",", "?", "!", "\'", "⌫"],
        ["ABC", "🌐","🐼","space", "↩"]
    ]
    
    static let symbolKeys = [
        ["[", "]", "{", "}", "#", "%", "^", "*", "+", "="],
        ["_", "\\", "|", "~", "<", ">", "€", "£", "¥", "·"],
        ["123",".", ",", "?", "!", "\'", "⌫"],
        ["ABC", "🌐","🐼", "space", "↩"]
    ]
    
    
}
