//
//  KeyboardShiftState.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 25/04/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
public enum ShiftButtonState
{
    case normal
    case shift
    case caps
}
