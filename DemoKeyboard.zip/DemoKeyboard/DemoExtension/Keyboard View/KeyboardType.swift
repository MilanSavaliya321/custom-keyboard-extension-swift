//
//  KeyboardType.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 25/04/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
public enum KeyboardState
{
    case letters
    case numbers
    case symbols
}


