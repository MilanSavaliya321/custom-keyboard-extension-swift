//
//  KeyboardViewController+Emoji.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 29/04/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit
import ISEmojiView
extension KeyboardViewController:EmojiViewDelegate
{
    
    //MARK: - emoji delegate
    func emojiViewDidPressChangeKeyboardButton(_ emojiView: EmojiView)
    {
        
        self.emojiView.isHidden = true;
        self.suggestionBarContainerView.isHidden = false;
        self.keysView.isHidden = false;
    }
    
    func emojiViewDidSelectEmoji(_ emoji: String, emojiView: EmojiView)
    {
        
        proxy.insertText(emoji)
        self.hapticConfiguration.tapFeedback.trigger();
        self.audioConfiguration.systemFeedback.trigger();
    }
    
    
    func emojiViewDidPressDeleteBackwardButton(_ emojiView: EmojiView)
    {
        
        proxy.deleteBackward()
        self.hapticConfiguration.tapFeedback.trigger()
        self.audioConfiguration.systemFeedback.trigger();
        
    }
}

