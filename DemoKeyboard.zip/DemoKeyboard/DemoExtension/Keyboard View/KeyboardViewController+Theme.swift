//
//  KeyboardViewController+Theme.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 02/05/20.
//  Copyright © 2020 Milan. All rights reserved.
//


import Foundation
import UIKit
import  BBPortal
extension KeyboardViewController
{
    //MARK: - setupAllPortal
    func setupAllNotificationPortal()
    {
        self.setupKeysColourChangePortal();
        self.setupThemeChangePortal();
        self.setupBrightnessOfBgPortal();
        self.setupUserCreatedThemePortal();
        self.setupViewThemwPortal()
        self.setupMakeDesignedKeyboardPortal()
        
    }
    func deleteInputText() {
        
        if let afterInput = self.textDocumentProxy.documentContextAfterInput {
            self.textDocumentProxy.adjustTextPosition(byCharacterOffset: afterInput.count)
        }
        while let _=self.textDocumentProxy.documentContextBeforeInput {
            
            self.textDocumentProxy.deleteBackward()
            
            
        }
        
    }
    //MARK: - select theme which you prefer
    func setupMakeDesignedKeyboardPortal()
    {
        makeDesignedKeyboardPortal = BBPortal(withGroupIdentifier: Constants.GroupID, andPortalID: Constants.portalID.makeDesignedKeyboard);
        makeDesignedKeyboardPortal?.onDataAvailable = {
            (data) in
            guard let imageName = data as? String else
            {
                
                return;
            }
            DispatchQueue.main.async {
                
                //self.deleteInputText();
                print("render image");
                
                let renderer = UIGraphicsImageRenderer(size: self.keysView.bounds.size)
                let image = renderer.image { ctx in
                    self.keysView.drawHierarchy(in: self.keysView.bounds, afterScreenUpdates: true)
                }
                
                if let fileManager = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.GroupID)
                {
                    // write your image name here;
                    let imageLocationUrl = fileManager.appendingPathComponent(imageName)
                    
                    // for saving image
                    
                    if let data:Data = image.pngData()
                    {
                        
                        do {
                            try data.write(to: imageLocationUrl)
                            
                        }catch {
                            print(".........couldn't write")
                        }
                    }
                }
                
            }
            
            
            
        }
        
        
    }
    func setupViewThemwPortal()
    {
        
        viewThemePortal = BBPortal(withGroupIdentifier: Constants.GroupID, andPortalID: Constants.portalID.viewTheme);
        viewThemePortal?.onDataAvailable =
            {
                (data) in
                guard let imgName = data as? String else
                {
                    
                    return;
                }
                DispatchQueue.main.async
                    {
                        if let fileManager = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.GroupID)
                        {
                            
                            let imageLocationUrl = fileManager.appendingPathComponent(imgName)
                            // for getting image
                            do {
                                let data:Data = try Data(contentsOf: imageLocationUrl);
                                let image = UIImage(data: data, scale: UIScreen.main.scale)
                                self.bgOfTheme.image  = image
                                self.bgOfTheme.contentMode = .scaleToFill;
                                for i in 0 ..< self.keys.count
                                {
                                    self.keys[i].bgImage.alpha = 0.7;
                                    self.keys[i].changeTheme(postfix: "_dark");
                                    
                                }
                                
                                if let spacekkey = self.spaceKey
                                {
                                    
                                    spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)_dark") ;
                                    
                                }
                                
                            }catch {
                                print("\n\nnot get data \n\n")
                                
                            }
                            
                            
                        }
                }
                
        }
    }
    func setupKeysColourChangePortal()
    {
        
        keysColourChangePortal = BBPortal(withGroupIdentifier: Constants.GroupID, andPortalID: Constants.portalID.SetKeysColour);
        keysColourChangePortal?.onDataAvailable =
            {
                (data) in
                guard let value = data as? String else
                {
                    
                    return;
                }
                DispatchQueue.main.async
                    {
                        for i in 0 ..< self.keys.count
                        {
                            self.keys[i].changeTheme(postfix: value);
                            
                        }
                        
                        if let spacekkey = self.spaceKey
                        {
                            
                            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.spaceImgPrefix)\(value)")
                            {
                                spacekkey.bgImage.image =  img;
                            }
                            else
                            {
                                spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)\(value)") ;
                                
                            }
                            
                        }
                }
                
        }
    }
    func setupBrightnessOfBgPortal()
    {
        bgBrighnessChangePortal = BBPortal(withGroupIdentifier: Constants.GroupID, andPortalID: Constants.portalID.bgBrightnessCahnge);
        bgBrighnessChangePortal?.onDataAvailable = {
            (data) in
            guard let value = data as? Float else
            {
                
                return;
            }
            
            DispatchQueue.main.async
                {
                    print(Constants.keyboardTheme)
                    print("Received segment value: \(value)");
                    self.bgOfTheme.alpha = CGFloat(value);
                    if(value == 0.0)
                    {
                        self.bgOfTheme.alpha = 0.2;
                    }
                    for i in 0 ..< self.keys.count
                    {
                        self.keys[i].bgImage.alpha = 0.5;
                        
                    }
                    
            }
            
            
            
        }
        
    }
    func setupUserCreatedThemePortal()
    {
        
        userCreatedThemePortal = BBPortal(withGroupIdentifier: Constants.GroupID, andPortalID: Constants.portalID.userCreatedThemeChange);
        
        userCreatedThemePortal?.onDataAvailable =
            {
                (data) in
                guard let value = data as? Int else
                {
                    
                    return;
                }
                DispatchQueue.main.async
                    {
                        
                        if let fileManager = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.GroupID)
                        {
                            
                            // write your image name here
                            guard  let imageName = "\(Constants.designbgImgPrefix)\(value)" as? String
                                else {return;}
                            
                            let imageLocationUrl = fileManager.appendingPathComponent(imageName)
                            // for getting image
                            do {
                                let data:Data = try Data(contentsOf: imageLocationUrl);
                                let image = UIImage(data: data, scale: UIScreen.main.scale)
                                self.bgOfTheme.image = image;
                                Constants.appGroupDefaults?.set( value, forKey: Constants.defaultsKey.UserCreatedThemeNo);
                                Constants.appGroupDefaults?.set( true, forKey: Constants.defaultsKey.isSelectedUserCreatedTheme);
                                Constants.appGroupDefaults?.synchronize();
                                
                                if let data = Constants.appGroupDefaults?.value(forKey:Constants.defaultsKey.DesignedThemeList) as? Data
                                {
                                    if let arr = try? PropertyListDecoder().decode(Array<CustomTheme>.self, from: data){
                                        
                                        print("\n\n\n\n\narr:\(arr[value - 1])")
                                        
                                        for i in 0 ..< self.keys.count
                                        {
                                            //self.keys[i].bgImage.alpha = 0.7;
                                            self.keys[i].changeTheme(postfix:     arr[value - 1].keyImg);
                                        }
                                        if let spacekkey = self.spaceKey
                                        {
                                            spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)\( arr[value - 1].keyImg)") ;
                                        }
                                        self.bgOfTheme.alpha = CGFloat(arr[value - 1].bgBrighness);
                                        
                                        
                                    }
                                    
                                }
                                
                            }catch {
                                print("\n\nnot get data \n\n")
                                
                            }
                        }
                        
                }
        }
        
    }
    func setupThemeChangePortal()
    {
        
        themeChangePortal = BBPortal(withGroupIdentifier: Constants.GroupID, andPortalID: Constants.portalID.ThemeChange);
        
        themeChangePortal?.onDataAvailable = { (data) in
            guard let value = data as? Int else
            {
                return;
            }
            
            Constants.keyboardTheme = value;
            DispatchQueue.main.async
                {
                    print("Received segment value: \(value)");
                    
                    if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.bgPrefix)\(value)", size: self.bgOfTheme.contentScaleFactor)
                    {
                        self.bgOfTheme.image =  img;
                    }
                    else
                    {
                        self.bgOfTheme.image = UIImage(named:"\(Constants.bgPrefix)\(value)") ;
                    }
                    
                    
                    print(self.keys.count)
                    for i in 0 ..< self.keys.count
                    {
                        self.keys[i].bgImage.alpha = 1.0;
                        self.keys[i].changeTheme(postfix: "\(Constants.keyboardTheme)");
                    }
                    if let spacekkey = self.spaceKey
                    {
                        if let spaceimg =  BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.spaceImgPrefix)\(value)", size: spacekkey.bgImage.contentScaleFactor)
                        {
                            spacekkey.bgImage.image = spaceimg
                        }
                        else
                        {
                            spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)\(value)") ;
                        }
                        
                    }
            }
        }
    }
    //MARK: - setup online theme
    func setupOnlineTheme()
    {
        
        let onlineThemeNo = (Constants.appGroupDefaults?.integer(forKey: Constants.defaultsKey.onlineThemeNo))!;
        Constants.keyboardTheme =  onlineThemeNo;
        DispatchQueue.main.async
            {
                if let img =  BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.bgPrefix)\(onlineThemeNo)", size: self.bgOfTheme.contentScaleFactor)
                {
                    self.bgOfTheme.image = img;
                }
                else
                {
                    self.bgOfTheme.image = UIImage(named: "\(Constants.bgPrefix)\(onlineThemeNo)")
                }
                for i in 0 ..< self.keys.count
                {
                    self.keys[i].bgImage.alpha = 1.0;
                    self.keys[i].changeTheme(postfix: "\(Constants.keyboardTheme)");
                }
                if let spacekkey = self.spaceKey
                {
                    if let spaceimg = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.spaceImgPrefix)\(onlineThemeNo)", size: spacekkey.bgImage.contentScaleFactor)
                    {
                        spacekkey.bgImage.image = spaceimg
                    }
                        
                    else
                    {
                        spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)\(onlineThemeNo)") ;
                    }
                    
                }
                
        }
        
    }
    //MARK: -  set Custom Theme
    func intiallySetCustomTheme()
    {
        
        if let fileManager = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.GroupID)
        {
            // write your image name here
            guard  let imageName = "\(Constants.designbgImgPrefix)\(((Constants.appGroupDefaults?.integer(forKey: Constants.defaultsKey.UserCreatedThemeNo))!))" as? String,let value =  (Constants.appGroupDefaults?.integer(forKey: Constants.defaultsKey.UserCreatedThemeNo))
                else {return;}
            
            let imageLocationUrl = fileManager.appendingPathComponent(imageName)
            // for getting image
            do {
                let data:Data = try Data(contentsOf: imageLocationUrl);
                let image = UIImage(data: data, scale: UIScreen.main.scale)
                self.bgOfTheme.image  = image
                self.bgOfTheme.contentMode = .scaleToFill;
                for i in 0 ..< self.keys.count
                {
                    self.keys[i].bgImage.alpha = 0.7;
                    self.keys[i].changeTheme(postfix: "_dark");
                    
                }
                
                if let spacekkey = self.spaceKey
                {
                    
                    spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)_dark") ;
                    
                }
                if let data = Constants.appGroupDefaults?.value(forKey:Constants.defaultsKey.DesignedThemeList) as? Data
                {
                    if let arr = try? PropertyListDecoder().decode(Array<CustomTheme>.self, from: data){
                        print("\n\n\n\n\narr:\(arr)")
                        for i in 0 ..< self.keys.count
                        {
                            self.keys[i].bgImage.alpha = 0.7;
                            self.keys[i].changeTheme(postfix: arr[value - 1].keyImg);
                        }
                        if let spacekkey = self.spaceKey
                        {
                            spacekkey.bgImage.image = UIImage(named:"\(Constants.spaceImgPrefix)\( arr[value - 1].keyImg)") ;
                        }
                        self.bgOfTheme.alpha = CGFloat(arr[value - 1].bgBrighness);
                        
                    }
                    
                }
                
            }catch {
                print("\n\nnot get data \n\n")
                
            }
            
        }
        
    }
    
}
