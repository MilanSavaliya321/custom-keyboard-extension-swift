//
//  KeyboardViewController+Autocomplete.swift
//  KeyboardKitDemoKeyboard
//
//  Created by Milan on 27/08/21.
//  Copyright © 2018 Milan.. All rights reserved.
//


import UIKit
extension KeyboardViewController
{
    
    //MARK: - auto suggestion use
    func setupSuggestionColectionView()
    {
        
        let nib = UINib(nibName: "SuggestionTextCollectionViewCell", bundle: nil);
        self.suggestionTextCollectionView.register(nib, forCellWithReuseIdentifier: Constants.cellID.suggestionTextCollectionCell)
        self.suggestionTextCollectionView.dataSource = self;
        self.suggestionTextCollectionView.delegate = self;
    }
    //MARK: - fucntion
    
    func requestAutocompleteSuggestions() {
        let word = textDocumentProxy.currentWord ?? ""
        autocompleteProvider.autocompleteSuggestions(for: word) { [weak self] in
            self?.handleAutocompleteSuggestionsResult($0)
        }
    }
    
    func resetAutocompleteSuggestions() {
        // autocompleteToolbar.reset() ;
        self.suggestionList.removeAll();
        self.suggestionTextCollectionView.reloadData();
    }
}

private extension KeyboardViewController {
    
    func handleAutocompleteSuggestionsResult(_ result: AutocompleteResult) {
        switch result {
        case .failure(let error): print(error.localizedDescription)
        case .success(let result):
            self.suggestionList.removeAll();
            self.suggestionList.append(contentsOf: result);
            self.suggestionTextCollectionView.reloadData();
            
            // autocompleteToolbar.update(with: result)
        }
    }
}
extension KeyboardViewController: UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate {
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Constants.cellID.suggestionTextCollectionCell, for: indexPath) as? CustomCell else {
            fatalError("can't dequeue CustomCell")
        }
        if(indexPath.row == 0 || indexPath.row == 2)
        {
            cell.backLine.isHidden = true;
            cell.frontLine.isHidden = true;
        }
        else
        {
            cell.backLine.isHidden = false;
            cell.frontLine.isHidden = false;
        }
        cell.label.textColor = Constants.keyFontColor;
        if(indexPath.row < self.suggestionList.count)
        {
            cell.label.text = "\(self.suggestionList[indexPath.row])"
        }
        else
        {
            cell.label.text = ""
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let width = self.suggestionTextCollectionView.bounds.width;
        let cell_width =  width/3;
        
        let height = self.suggestionTextCollectionView.bounds.height;
        return CGSize(width: cell_width, height: cell_width)
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if(self.suggestionList.count > 0)
        {
            if(indexPath.row < self.suggestionList.count) {
                if(!self.suggestionList[indexPath.row].isEmpty)
                {
                    let text = self.suggestionList[indexPath.row] + " ";
                    proxy.replaceCurrentWord(with: text);
                    
                }
            }
        }
    }
}
