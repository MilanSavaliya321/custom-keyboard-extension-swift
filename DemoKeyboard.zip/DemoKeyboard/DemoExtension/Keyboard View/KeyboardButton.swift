//
//  KeyboardButton.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 29/04/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit

extension UIButton
{
    func set(fontSize: CGFloat)
    {
        if let titleLabel = titleLabel
        {
            titleLabel.font = UIFont(name: titleLabel.font.fontName, size: fontSize)
        }
    }
}

class KeyboardButton: UIView
{
    
    let bgDefaultImge =  (UIImage(named: "\(Constants.btnImgPrefix)1")?.resizableImage(withCapInsets: UIEdgeInsets(top: 10, left: 18, bottom: 10, right: 18), resizingMode: .stretch))
    
    var keyToDisplay:String = "";
    var original:String = "";
    var theme:Int = 4;
    
    lazy var addButton: UIButton =
        {
            let addButton = UIButton(type: .system)
            addButton.setTitle(keyToDisplay, for: .normal)
            addButton.tintColor = Constants.keyFontColor; addButton.translatesAutoresizingMaskIntoConstraints = false;
            addButton.backgroundColor = .clear//Constants.keyNormalColour
            addButton.titleLabel!.font =  UIFont.systemFont(ofSize: BasicMethod.device_IS_IPAD() ? 30 : 20)
//            addButton.titleLabel!.font =  UIFont.systemFont(ofSize: 30)
            addButton.setTitleColor(.white, for: .normal)
            addButton.layer.setValue(original, forKey: "original")
            addButton.layer.setValue(original, forKey: "keyToDisplay")
            addButton.layer.setValue(false, forKey: "isSpecial")
            return addButton
    }()
    //var bgImage: UIImageView = UIImageView.init();
    var bgImage: UIImageView =
    {
        let contentView = UIImageView();
        contentView.image = (UIImage(named: "\(Constants.btnImgPrefix)1")?.resizableImage(withCapInsets: UIEdgeInsets(top: 10, left: 18, bottom: 10, right: 18), resizingMode: .stretch))
        contentView.translatesAutoresizingMaskIntoConstraints = false;
        
        return contentView;
    }()
    
    var specialKeyImage: UIImageView =
    {
        let contentView = UIImageView();
        contentView.translatesAutoresizingMaskIntoConstraints = false;
        contentView.contentMode = .scaleAspectFit
        
        return contentView;
    }()
    
    override class var requiresConstraintBasedLayout: Bool
    {
        return true
    }
    
    override init(frame: CGRect)
    {
        super.init(frame: CGRect.zero)
    }
    init(displayTxt:String,theme:Int)
    {
        super.init(frame:CGRect.zero)
        keyToDisplay = displayTxt;
        original = displayTxt;
        self.theme = theme
        
        setupView();
        
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        fatalError("init(coder:) has not been implemented");
    }
    
    public func setupView()
    {
        
        backgroundColor = .clear;
        if let fontColor = Constants.appGroupDefaults?.value(forKey:"\(Constants.defaultsKey.onlineThemeFontColorPrefix)\(Constants.keyboardTheme)") as? String
        {
            Constants.keyFontColor = UIColor.colorWithHexString(hexString: fontColor); self.addButton.setTitleColor(UIColor.colorWithHexString(hexString: fontColor),for:.normal)
        }
        else
        {
            self.addButton.setTitleColor(.white ,for:.normal)
        }
        if let img = BasicMethod
            .getImageFromAppGroupShareContainer(imgName: "\(Constants.btnImgPrefix)\(Constants.keyboardTheme)")
        {
            bgImage.image = img
        }
        else
        {
            
            bgImage.image =  bgDefaultImge
        }
        
        if(original == "space")
        {
            
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.spaceImgPrefix)\(Constants.keyboardTheme)")
            {
                bgImage.image = img
            }
            else
            {
                bgImage.image = UIImage(named: "\(Constants.spaceImgPrefix)0")!;
            }
            
        }
        addSubview(bgImage);
        self.addSpecialKey();
        addSubview(addButton);
        setupLayout();
        self.setupActions();
    }
    private func setupLayout()
    {
        bgImage.bindFrameToSuperviewBounds();
        addButton.bindFrameToSuperviewBounds();
    }
    func setAsCapitalKey()
    {
        self.specialKeyImage.image  = UIImage(named: "capital");
        
        if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.lockedKeyPrefix)\(Constants.keyboardTheme)")
        {
            self.specialKeyImage.image = img
        }
        else
        {
            self.specialKeyImage.image  = UIImage(named: "capital");
        }
        
        
    }
    func addSpecialKey()
    {
        
        switch original
        {
            
        case keyType.Captilized.rawValue,keyType.numberised.rawValue,keyType.symbolised.rawValue:
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.specialImgPrefix)\(Constants.keyboardTheme)")
            {
                bgImage.image = img
            }
            else
            {
                bgImage.image =  bgDefaultImge
            }
            break;
            
            
        case keyType.backSpace.rawValue:
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.deleteImgPrefix)\(Constants.keyboardTheme)")
            {
                self.specialKeyImage.image = img
            }
            else
            {
                self.specialKeyImage.image = UIImage(named: "delete");
            }
            
            
            self.addSubview(specialKeyImage)
            self.addButton.setTitle("", for: .normal); specialKeyImage.bindFrameToSuperviewBounds(withMultiplier: 0.4);
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.specialImgPrefix)\(Constants.keyboardTheme)")
            {
                bgImage.image = img
            }
            else
            {
                bgImage.image =  bgDefaultImge
            }
            break;
        case keyType.empoji.rawValue:
            
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.emojiPrefix)\(Constants.keyboardTheme)")
            {
                self.specialKeyImage.image = img
            }
            else
            {
                self.specialKeyImage.image = UIImage(named: "emoji");
            }
            self.addSubview(specialKeyImage)
            self.addButton.setTitle("", for: .normal); specialKeyImage.bindFrameToSuperviewBounds(withMultiplier: 0.4);
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.specialImgPrefix)\(Constants.keyboardTheme)")
            {
                bgImage.image = img
            }
            else
            {
                bgImage.image =  bgDefaultImge
            }
            break;
            
        case keyType.browser.rawValue:
            // self.specialKeyImage.image  = UIImage(named: "browser");
            self.addSubview(specialKeyImage)
            self.addButton.tintColor = Constants.keyFontColor;
            
            
            self.addButton.setImage(UIImage(named: "browser"), for: .normal)
            self.addButton.setTitle("", for: .normal); specialKeyImage.bindFrameToSuperviewBounds(withMultiplier: 0.4);
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.specialImgPrefix)\(Constants.keyboardTheme)")
            {
                bgImage.image = img
            }
            else
            {
                bgImage.image = bgDefaultImge
            }
            break;
        case keyType.newLine.rawValue:
            
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.newLineimgPrefix)\(Constants.keyboardTheme)")
            {
                self.specialKeyImage.image = img
            }
            else
            {
                self.specialKeyImage.image  = UIImage(named: "newLine");
            }
            self.addSubview(specialKeyImage)
            self.addButton.setTitle("", for: .normal); specialKeyImage.bindFrameToSuperviewBounds(withMultiplier: 0.35);
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName:            "\(Constants.specialImgPrefix)\(Constants.keyboardTheme)")
            {
                bgImage.image = img
            }
            else
            {
                bgImage.image =  bgDefaultImge
            }
            break;
            
        case keyType.shift.rawValue:
            
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.ShiftKeyPrefix)\(Constants.keyboardTheme)")
            {
                self.specialKeyImage.image = img
            }
            else
            {
                self.specialKeyImage.image  = UIImage(named: "small");
            }
            self.addSubview(specialKeyImage)
            self.addButton.setTitle("", for: .normal); specialKeyImage.bindFrameToSuperviewBounds(withMultiplier: 0.4);
            if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.specialImgPrefix)\(Constants.keyboardTheme)")
            {
                bgImage.image = img
            }
            else
            {
                bgImage.image =  bgDefaultImge
            }
            break;
            
        default:
            break;
            
            
            
        }
    }
    private func setupActions()
    {
        
    }
    func setKeyToDisplay(str:String)
    {
        self.keyToDisplay = str;
        self.addButton.layer.setValue(str, forKey: "keyToDisplay");
    }
    
    func setTitle(key:String)
    {
        self.keyToDisplay = key;
        self.addButton.setTitle(key, for: .normal)
        
    }
    
    func changeTheme(postfix:String)
    {
        
        if let fontColor = Constants.appGroupDefaults?.value(forKey:"\(Constants.defaultsKey.onlineThemeFontColorPrefix)\(postfix)") as? String
        {
            print("\n\n\n\n........\(fontColor)");
            
            Constants.keyFontColor = UIColor.colorWithHexString(hexString: fontColor); self.addButton.setTitleColor(UIColor.colorWithHexString(hexString: fontColor),for:.normal)
        }
        else
        {
            self.addButton.setTitleColor(.white ,for:.normal);
        }
        if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.btnImgPrefix)\(postfix)")
        {
            
            self.bgImage.image = img;
            if(self.original == "space")
            {
                
                if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.spaceImgPrefix)\(postfix)")
                {
                    self.bgImage.image = img;
                    
                }
                else
                {
                    self.bgImage.image =
                        UIImage(named: "\(Constants.spaceImgPrefix)\(postfix)")!;
                }
                
            }
            if(original ==  keyType.backSpace.rawValue || original ==  keyType.empoji.rawValue || original ==  keyType.browser.rawValue || original ==  keyType.newLine.rawValue ||  original ==  keyType.shift.rawValue || original ==  keyType.Captilized.rawValue ||
                original ==  keyType.numberised.rawValue ||
                original ==  keyType.symbolised.rawValue || original ==  keyType.browser.rawValue)
            {
                switch original {
                case keyType.browser.rawValue:
                    self.addButton.tintColor = Constants.keyFontColor;
                    break;
                case keyType.empoji.rawValue:
                    if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.emojiPrefix)\(postfix)")
                    {
                        self.specialKeyImage.image = img
                    }
                    else
                    {
                        self.specialKeyImage.image = UIImage(named: "emoji");
                    }
                    
                    break;
                case keyType.backSpace.rawValue:
                    if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.deleteImgPrefix)\(postfix)")
                    {
                        self.specialKeyImage.image = img
                    }
                    else
                    {
                        self.specialKeyImage.image = UIImage(named: "delete");
                    }
                    break;
                case keyType.newLine.rawValue:
                    if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.newLineimgPrefix)\(postfix)")
                    {
                        self.specialKeyImage.image = img
                    }
                    else
                    {
                        self.specialKeyImage.image = UIImage(named: "newLine");
                        
                    }
                    break;
                    
                case keyType.shift.rawValue:
                    if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.ShiftKeyPrefix)\(postfix)")
                    {
                        self.specialKeyImage.image = img
                    }
                    else
                    {
                        self.specialKeyImage.image = UIImage(named: "small");
                    }
                    break;
                default:
                    break;
                }
                
                
                if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.specialImgPrefix)\(Constants.keyboardTheme)")
                {
                    bgImage.image = img
                }
                else
                {
                    bgImage.image =  bgDefaultImge
                }
                
            }
            
        }
        else
        {
            self.bgImage.image = UIImage(named: "\(Constants.btnImgPrefix)\(postfix)")!;
            if(self.original == "space")
            {
                self.bgImage.image = UIImage(named: "\(Constants.spaceImgPrefix)\(postfix)")!;
                
            }
        }
        
        
        //UIImage(named: "\(Constants.btnImgPrefix)\(postfix)")!;
        
        
    }
    
    func setAsSpaceBtn(postfix:String)
    {
        
        self.bgImage.backgroundColor = .red
        if let img = BasicMethod.getImageFromAppGroupShareContainer(imgName: "\(Constants.spaceImgPrefix)\(postfix)")
        {
            self.bgImage.image =  img;
        }
        else
        {
            self.bgImage.image = UIImage(named: "\(Constants.spaceImgPrefix)\(postfix)")!;
        }
        
    }
    func setOriginalValueToBtn(key:String)
    {
        self.addButton.layer.setValue(key, forKey: "original");
    }
    func setDisplayValueToBtn(key:String)
    {
        self.addButton.layer.setValue(key, forKey: "keyToDisplay");
        self.setKeyToDisplay(str: key);
    }
    func isSpecial(set:Bool)
    {
        addButton.layer.setValue(false, forKey: "isSpecial")
    }
    
    
}
