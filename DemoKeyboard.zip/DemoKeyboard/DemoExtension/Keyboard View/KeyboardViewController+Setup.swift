//
//  KeyboardViewController+Setup.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 27/04/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import  UIKit
extension KeyboardViewController
{
    
    func loadInterfaceFromXIB()
    {        
        let keyboardNib = UINib(nibName: "Keyboard", bundle: nil)
        keyboardView = keyboardNib.instantiate(withOwner: self, options: nil)[0] as? UIView;
        keyboardView.frame.size =  self.view.frame.size
        view.addSubview(keyboardView);
        loadKeys()
    }
    
    func setupCustomHeightOfKeyboard()
    {
        // self.inputView?.heightAnchor.constraint(equalToConstant: portraitHeight);
        
        let heightConstraint = NSLayoutConstraint(item: view!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 0.0, constant:portraitHeight);
        heightConstraint.priority = UILayoutPriority(rawValue: 999)
        view.addConstraint(heightConstraint)
        
        
        print("portraitHeight == ",portraitHeight)
    }
    
    func addPadding(to stackView: UIStackView, width: CGFloat, key: String){
        let padding = UIButton(frame: CGRect(x: 0, y: 0, width: 5, height: 5))
        padding.backgroundColor = .clear
        padding.setTitleColor(.clear, for: .normal);
        padding.alpha = 1.0//0.02;
        padding.translatesAutoresizingMaskIntoConstraints = false;
        padding.widthAnchor.constraint(equalToConstant: width  ).isActive = true;
        
        //if we want to use this padding as a key, for example the a and l buttons
        //        let keyToDisplay = shiftButtonState == .normal ? key : key.capitalized
        //        padding.layer.setValue(key, forKey: "original")
        //        padding.layer.setValue(keyToDisplay, forKey: "keyToDisplay")
        //        padding.layer.setValue(false, forKey: "isSpecial");
        //        padding.addTarget(self, action: #selector(keyPressedTouchUp), for: .touchUpInside)
        //        padding.addTarget(self, action: #selector(keyTouchDown), for: .touchDown)
        //        padding.addTarget(self, action: #selector(keyUntouched), for: .touchDragExit);
        paddingViews.append(padding);
        stackView.addArrangedSubview(padding);
    }
    
    func removeAllKeys()
    {
        keys.forEach
            {
                $0.removeFromSuperview();
        }
        
        paddingViews.forEach{$0.removeFromSuperview()}
        
    }
    func addPaddingInKeyRows()
    {
        let buttonWidth = (UIScreen.main.bounds.width) / CGFloat(Constants.letterKeys[0].count);
        //start padding
        switch keyboardState
        {
            
        case .letters:
            self.addPadding(to: stackView2, width: buttonWidth/2, key: "a");
        case .numbers:
            break;
        case .symbols:
            break;
        }
        
    }
    
    
    //TEMP
    @objc func longPress( sender: Any) {
        
        let longPressGesture = sender as! UILongPressGestureRecognizer
        
        //Only run this code When State Begain
        if longPressGesture.state != UIGestureRecognizer.State.began {
            return
        }
        // if PopUpView is Already in added than remove and than  add
        if let checkView = self.view.viewWithTag(1001) as? UIView {
            // remove popView
            popUpView.removeFromSuperview()
        }
        
        let tapLocation = longPressGesture.location(in: self.view)
        
        
        popUpView = UIView(frame: CGRect(x: tapLocation.x-10, y: tapLocation.y-65, width: 110, height: 50))
        popUpView.backgroundColor=UIColor.orange
        popUpView.layer.cornerRadius=5
        popUpView.layer.borderWidth=2
        popUpView.tag=1001
        popUpView.layer.borderColor=UIColor.black.cgColor
        
        let btn0: UIButton=UIButton(frame: CGRect(x: 5, y: 5, width: 35, height: 40))
        btn0.setTitle("A1", for: .normal)
        btn0.setTitleColor(UIColor.black, for: .normal);
        btn0.layer.borderWidth=0.5
        btn0.layer.borderColor=UIColor.lightGray.cgColor
        
        popUpView.addSubview(btn0)
        
        let btn1: UIButton=UIButton(frame: CGRect(x: 35, y: 5, width: 35, height: 40))
        btn1.setTitle("A2", for: .normal)
        btn1.setTitleColor(UIColor.black, for: .normal);
        btn1.layer.borderWidth=0.5
        btn1.layer.borderColor=UIColor.lightGray.cgColor
        
        popUpView.addSubview(btn1)
        
        let btn2: UIButton=UIButton(frame: CGRect(x: 70, y: 5, width: 35, height: 40))
        btn2.setTitle("A3", for: .normal)
        btn2.setTitleColor(UIColor.black, for: .normal);
        btn2.layer.borderWidth=0.5
        btn2.layer.borderColor=UIColor.lightGray.cgColor
        
        popUpView.addSubview(btn2)
        
        btn0.addTarget(self, action: #selector(self.buttonAction(sender:)),
                       for: UIControl.Event.touchUpInside)
        btn1.addTarget(self, action: #selector(self.buttonAction(sender:)),
                       for: UIControl.Event.touchUpInside)
        btn2.addTarget(self, action: #selector(self.buttonAction(sender:)),
                       for: UIControl.Event.touchUpInside)
        
        self.view.addSubview(popUpView)
        
        
    }
    
    //TEMP
    @objc func buttonAction( sender: UIButton) {
        
        // Do your Stuff Here
        
        
        //Than remove popView
        proxy.insertText((sender.titleLabel?.text)!);
        
        popUpView.removeFromSuperview()
    }
    
    func loadKeys()
    {
        //For landscape / portrait
        if UIScreen.main.bounds.height > UIScreen.main.bounds.width {
            stackView1.alignment = .fill
            stackView2.alignment = .fill
            stackView3.alignment = .fill
            stackView4.alignment = .fill
            
            stackView1.distribution = .fillEqually
            stackView2.distribution = .equalSpacing
            stackView3.distribution = .equalSpacing
            stackView4.distribution = .fillProportionally
        } else {
            stackView1.alignment = .fill
            stackView2.alignment = .fill
            stackView3.alignment = .fill
            stackView4.alignment = .fill
            
            stackView1.distribution = .fillEqually
            stackView2.distribution = .fillEqually
            stackView3.distribution = .fillEqually
            stackView4.distribution = .fill
        }
        
        stackView1.layoutIfNeeded()
        stackView2.layoutIfNeeded()
        stackView3.layoutIfNeeded()
        stackView4.layoutIfNeeded()
        
        self.removeAllKeys();
        print("\n\n load keys \n\n")
        var keyboard: [[String]]
        let buttonWidth = (UIScreen.main.bounds.width) / CGFloat(Constants.letterKeys[0].count);
        //start padding
        self.addPaddingInKeyRows();
        
        switch keyboardState
        {
            
        case .letters:
            keyboard = Constants.letterKeys;
        case .numbers:
            keyboard = Constants.numberKeys
        case .symbols:
            keyboard = Constants.symbolKeys
        }
        
        let numRows = keyboard.count
        for row in 0...numRows - 1
        {
            for col in 0...keyboard[row].count - 1
            {
                
                let key = keyboard[row][col];
                let keyboardbtn = KeyboardButton(displayTxt: key, theme:Constants.keyboardTheme);
                
                let capsKey = keyboard[row][col].capitalized
                
                var keyToDisplay:String = ""
                
                if capsKey == "Space" {
                    keyToDisplay = "space"
                } else {
                    keyToDisplay = shiftButtonState == .normal ? key : capsKey
                    print("capitalized =",capsKey)
                }
                
                
                //                keyboardbtn.layer.setValue(key, forKey: "original")
                //                keyboardbtn.layer.setValue(keyToDisplay, forKey: "keyToDisplay")
                //                keyboardbtn.layer.setValue(false, forKey: "isSpecial")
                keyboardbtn.setTitle(key: keyToDisplay);
                keyboardbtn.addSpecialKey();
                keyboardbtn.addButton.addTarget(self, action: #selector(keyPressedTouchUp), for: .touchUpInside)
                keyboardbtn.addButton.addTarget(self, action: #selector(keyTouchDown), for: .touchDown)
                keyboardbtn.addButton.addTarget(self, action: #selector(keyUntouched), for: .touchDragExit)
                keyboardbtn.addButton.addTarget(self, action: #selector(keyMultiPress(_:event:)), for: .touchDownRepeat)
                
                
                //TEMP
                let longGesture = UILongPressGestureRecognizer(target: self, action: #selector(longPress(sender:)))
                longGesture.minimumPressDuration = 0.4
                keyboardbtn.addButton.addGestureRecognizer(longGesture)
                
                
                if key == keyType.backSpace.rawValue
                {
                    let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(keyLongPressed(_:)))
                    keyboardbtn.addButton.addGestureRecognizer(longPressRecognizer)
                }
                
                keys.append(keyboardbtn);
                
                
                
                switch row
                {
                case 0: stackView1.addArrangedSubview(keyboardbtn)
                case 1: stackView2.addArrangedSubview(keyboardbtn);
                case 2: stackView3.addArrangedSubview(keyboardbtn);
                case 3: stackView4.addArrangedSubview(keyboardbtn);
                default:
                    break
                }
                
                if key == keyType.browser.rawValue
                {
                    nextKeyboardButton = keyboardbtn.addButton;
                }
                
                
                //top row is longest row so it should decide button width
                
                if key == keyType.backSpace.rawValue || key == keyType.newLine.rawValue || key == "#+=" || key == "ABC" || key == "123" || key == keyType.shift.rawValue || key == keyType.browser.rawValue || key == keyType.empoji.rawValue
                {
                    
                    keyboardbtn.widthAnchor.constraint(equalToConstant: buttonWidth + buttonWidth/2).isActive = true;
                    
                    keyboardbtn.isSpecial(set: true)
                    
                    
                    if key == keyType.shift.rawValue
                    {
                        if shiftButtonState != .normal{
                            //keyboardbtn.addButton.backgroundColor = Constants.keyPressedColour
                        }
                        if shiftButtonState == .caps
                        {
                            keyboardbtn.setAsCapitalKey();
                        }
                    }
                }else if (keyboardState == .numbers || keyboardState == .symbols) && row == 2
                {
                    keyboardbtn.widthAnchor.constraint(equalToConstant: buttonWidth * 1.4).isActive = true
                    //                    keyboardbtn.widthAnchor.constraint(equalToConstant: buttonWidth).isActive = true
                    
                } 
                else if(row == 1)
                {
                    keyboardbtn.widthAnchor.constraint(equalToConstant: buttonWidth).isActive = true
                }
                else if key != keyType.space.rawValue
                {
                    keyboardbtn.widthAnchor.constraint(equalToConstant: buttonWidth).isActive = true;
                    
                }else{
                    keyboardbtn.setOriginalValueToBtn(key: key);
                    //  keyboardbtn.setTitle(key: key);
                    
                }
            }
        }       
        //end padding
        switch keyboardState
        {
        case .letters:
            self.addPadding(to: stackView2, width: buttonWidth/2, key: "l")
        case .numbers:
            break
        case .symbols: break
        }
        
    }
    
    
}
