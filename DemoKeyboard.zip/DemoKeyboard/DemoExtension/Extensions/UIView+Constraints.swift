//
//  UIView+Constraints.swift
//  CustomKeyboardExtension
//
//  Created by Milan on 27/08/21.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit

extension UIView {

    /// Adds constraints to this `UIView` instances `superview` object to make sure this always has the same size as the superview.
      /// Please note that this has no effect if its `superview` is `nil` – add this `UIView` instance as a subview before calling this.
      func bindFrameToSuperviewBounds()
      {
          
          guard let superview = self.superview
          else
          {
              print("Error! `superview` was nil – call `addSubview(view: UIView)` before calling `bindFrameToSuperviewBounds()` to fix this.");
              return;
          }
          
          self.translatesAutoresizingMaskIntoConstraints = false;
          let s = NSLayoutConstraint.activate([
          self.centerXAnchor.constraint(equalTo: superview.centerXAnchor),
          self.widthAnchor.constraint(equalTo: superview.widthAnchor, multiplier: 0.9),
          self.heightAnchor.constraint(equalTo: superview.heightAnchor, multiplier: 0.85),
           self.centerYAnchor.constraint(equalTo: superview.centerYAnchor),
          ])
          


      }
    func bindFrameToSuperviewBounds(withMultiplier:CGFloat)
         {
             
             guard let superview = self.superview
             else
             {
                 print("Error! `superview` was nil – call `addSubview(view: UIView)` before calling `bindFrameToSuperviewBounds()` to fix this.");
                 return;
             }
             
             self.translatesAutoresizingMaskIntoConstraints = false;
             let s = NSLayoutConstraint.activate([
             self.centerXAnchor.constraint(equalTo: superview.centerXAnchor),
             self.widthAnchor.constraint(equalTo: superview.widthAnchor, multiplier: withMultiplier),
             self.heightAnchor.constraint(equalTo: superview.heightAnchor, multiplier: withMultiplier),
              self.centerYAnchor.constraint(equalTo: superview.centerYAnchor),
             ])
             


         }
    func removeAllConstraints() {
        var parent = self.superview

        while let superview = parent {
            for constraint in superview.constraints {

                if let first = constraint.firstItem as? UIView, first == self {
                    superview.removeConstraint(constraint)
                }

                if let second = constraint.secondItem as? UIView, second == self {
                    superview.removeConstraint(constraint)
                }
            }

            parent = superview.superview
        }

        removeConstraints(constraints)
        translatesAutoresizingMaskIntoConstraints = true
    }
}
