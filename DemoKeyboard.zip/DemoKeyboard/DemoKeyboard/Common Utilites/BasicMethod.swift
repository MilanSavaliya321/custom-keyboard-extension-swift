//
//  BasicMethod.swift
//  CustomKeyboard
//
//  Created by Milan on 27/08/21.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit
import Photos
import Reachability

class BasicMethod
{
    
    //MARK: - Network connectivity
    class func isConnectedToNetwork()->Bool
    {
        let networkReachability: Reachability = Reachability.forInternetConnection();
        let networkStatus : NetworkStatus = networkReachability.currentReachabilityStatus();
        if (networkStatus.rawValue == 0) {
            return false;
        }
        else
        {
            return true;
        }
    }
    //MARK: - Alert View
    
    class func showAlertView(view:UIViewController,mess:String)
    {
        let alertController = UIAlertController(title: "Alert", message:mess, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        view.present(alertController, animated: true, completion: nil)
        
    }
    //MARK: permission
    class func checkPhotosPermission() -> Bool
    {
        var isValid:Bool = false;
        let photos = PHPhotoLibrary.authorizationStatus();
        
        if photos == .authorized
        {
            return  true;
        }
        else
        {
            
            PHPhotoLibrary.requestAuthorization({status in
                if status == .authorized
                {
                    
                    isValid =  true;
                }
                else if status == .denied
                {
                    isValid =  false;
                }
                else if status == .restricted
                {
                    isValid =  false
                }
            })
            return isValid
        }
        
    }
    class func PhotoPermissionAuthorize(_ authorized: @escaping () -> Void)
    {
        PHPhotoLibrary.requestAuthorization { (status) in
            print("\n\n\n\n\n\(status)\n\n")
            switch status {
                
                
            case .authorized:
                DispatchQueue.main.async(execute: authorized)
            default:
                break
            }
            
        }
        
    }
    //MARK: - Share Container APP Group
    class func saveImageToAppGroupContainer(image:UIImage,imgName:String) ->  Bool
    {
        if let fileManager = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.GroupID)
        {
            // write your image name here;
            let imageLocationUrl = fileManager.appendingPathComponent(imgName)
            // for saving image
            if let data:Data = image.pngData()
            {
                
                do
                {
                    try data.write(to: imageLocationUrl)
                    
                }catch
                {                            print("\n\n.........couldn't save image in Appcontainer...")
                    return false;
                }
            }
            print("save in app group...")
            return true
        }
        print("not save in app group...")
        return false;
    }
    class func getImageFromAppGroupShareContainer(imgName:String,size:CGFloat = UIScreen.main.scale) -> UIImage?
    {
        if let fileManager = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.GroupID)
        {
            
            let imageName = imgName // write your image name here
            let imageLocationUrl = fileManager.appendingPathComponent(imageName)
            
            // for getting image
            do {
                let data:Data = try Data(contentsOf: imageLocationUrl);
                let image = UIImage(data: data, scale: size)
                
                return  image //SWNinePatchImageFactory.createResizableNinePatchImage(image);
            }catch
            {
                print(error);
                return nil
            }
            
        }
        return nil
    }
    //MARK: - save image in local
    
    class func saveImage(imageName: String, image: UIImage)
    {
        
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let fileName = imageName
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        guard let data = image.jpegData(compressionQuality: 1) else { return }
        
        //Checks if file exists, removes it if so.
        
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            do {
                try FileManager.default.removeItem(atPath: fileURL.path)
                print("Removed old image")
            } catch let removeError {
                print("couldn't remove file at path", removeError)
            }
            
        }
        
        do {
            try data.write(to: fileURL)
        } catch let error {
            print("error saving file with error", error)
        }
        
    }
    
    class  func loadImageFromDiskWith(fileName: String) -> UIImage?
    {
        print("\n\n\n\nhello kitty\n\n\n\n");
        let documentDirectory = FileManager.SearchPathDirectory.documentDirectory
        
        let userDomainMask = FileManager.SearchPathDomainMask.userDomainMask;
        let paths = NSSearchPathForDirectoriesInDomains(documentDirectory, userDomainMask, true);
        
        if let dirPath = paths.first
        {
            
            let imageUrl = URL(fileURLWithPath: dirPath).appendingPathComponent(fileName);
            let image = UIImage(contentsOfFile: imageUrl.path)
            return image;
        }
        print("\n\nnot give image...\n\n\n\n")
        return nil
    }
    //MARK: -  keyboard setting functions
    class func isKeyboardExtensionEnabled() -> Bool {
        guard let appBundleIdentifier = Bundle.main.bundleIdentifier else {
            fatalError("isKeyboardExtensionEnabled(): Cannot retrieve bundle identifier.")
        }
        
        guard let keyboards = UserDefaults.standard.dictionaryRepresentation()["AppleKeyboards"] as? [String] else {
            // There is no key `AppleKeyboards` in NSUserDefaults. That happens sometimes.
            return false
        }
        
        let keyboardExtensionBundleIdentifierPrefix = appBundleIdentifier + "."
        for keyboard in keyboards {
            if keyboard.hasPrefix(keyboardExtensionBundleIdentifierPrefix) {
                return true
            }
        }
        
        return false
    }
    static func isAllowFullAccess() -> Bool {
        let fm = FileManager.default
        let containerPath = fm.containerURL(
            forSecurityApplicationGroupIdentifier: Constants.GroupID)?.path
        //var error: NSError?
        do
        {
            try  fm.contentsOfDirectory(atPath: containerPath!)
        }
        catch
        {
            if (error != nil)
            {
                NSLog("Full Access: Off")
                return false
            }
        }
        
        
        NSLog("Full Access: On");
        return true
    }
    //MARK: - Device Configuration
    class func checkDeviceConfiguration()
    {
        switch UIDevice.current.userInterfaceIdiom
        {
            
        case .phone:
            
            Constants.Device.type = Constants.UIUserInterfaceIdiom.phone
            break
        case .pad:
            Constants.Device.type = Constants.UIUserInterfaceIdiom.pad
            
            break;
        case .unspecified:
            Constants.Device.type = Constants.UIUserInterfaceIdiom.unspecified
            break
        case .tv:
            Constants.Device.type = Constants.UIUserInterfaceIdiom.unspecified
            break
        case .carPlay:
            Constants.Device.type = Constants.UIUserInterfaceIdiom.unspecified
            break
        @unknown default:
            Constants.Device.type = Constants.UIUserInterfaceIdiom.unspecified
            break
        }
        
    }
    class func device_IS_IPAD() -> Bool
    {
        if(Constants.appGroupDefaults!.bool(forKey: Constants.defaultsKey.IS_IPad) )
        {
            
            return true
            
        }
        else
        {
            return false
        }
        
    }
}
