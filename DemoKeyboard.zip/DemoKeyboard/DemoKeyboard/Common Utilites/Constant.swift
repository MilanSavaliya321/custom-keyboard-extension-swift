//
//  Constant.swift
//  CustomKeyboard
//
//  Created by Milan on 27/08/21.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit
//MARK: - constant

let Defaults = UserDefaults.standard;

class Constant
{
    
    static let nativeMediumAdsHeight:CGFloat =  Constants.Device.IS_IPAD ? 700 : 450;
    static var previewTF: UITextField? = UITextField();
    //      static  let PagerBar  = PageViewController();
    //MARK:  - colours
    static let AppThemeColor  =  #colorLiteral(red: 0.2467366457, green: 0.3927409053, blue: 1, alpha: 1)

    public  struct defaultsKey
    {
        static  let  isGetStartedVCLoaded = "isGetStartedVCLoaded"
        static  let  isKeyboardInstallationCompleted = "isKeyboardInstallationCompleted"
        static  let  onHomeScreen = "onHomeScreen"
        
    }
    

    public  struct  notificationID
    {
        static let openDesignThemevc = "openDesignThemevc"
        static let KeyboardShow = "KeyboardShow"
    }
    
}

