//
//  ShareContainer.swift
//  CustomKeyboard
//
//  Created by Milan on 27/08/21.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
class  ShareContainer
{
    class func saveData()
    {
        
    }
}
