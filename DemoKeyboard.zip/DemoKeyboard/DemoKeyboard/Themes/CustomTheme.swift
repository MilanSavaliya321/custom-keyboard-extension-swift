//
//  CustomTheme.swift
//  CustomKeyboard
//
//  Created by Milan on 27/08/21.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
struct CustomTheme : Codable
{
    var themeId: Int
    var bgImg: String
    var keyImg: String
    var bgBrighness: Float
    var keyboardImg:String
}
//"themeId"     : "1",
//     "bgImg"       : "bgdesignPrefix1",
//     "keyImg"      : "dark",
//     "bgBrighness" : "0.5"
