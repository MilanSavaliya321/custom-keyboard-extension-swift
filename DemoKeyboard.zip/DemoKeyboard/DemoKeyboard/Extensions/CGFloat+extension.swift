//
//  CGFloat+extension.swift
//  CustomKeyboard
//
//  Created by Milan on 01/06/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit
extension CGFloat {
     static func random() -> CGFloat {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}
