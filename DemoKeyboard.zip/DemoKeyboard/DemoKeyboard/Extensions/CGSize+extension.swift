//
//  CGsize+extension.swift
//  CustomKeyboard
//
//  Created by Milan on 01/06/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import  UIKit
extension CGSize
{
    
func resize(by scale: CGFloat) -> CGSize {
    return CGSize(width: self.width * scale, height: self.height * scale)
    }
}
