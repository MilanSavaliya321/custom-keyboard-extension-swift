//
//  UIImage+Extension.swift
//  CustomKeyboard
//
//  Created by Milan on 27/08/21.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import UIKit

extension UIImageView
{
    func enableZoom()
    {
        
      let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(startZooming(_:)))
        self.isUserInteractionEnabled = true;
      self.addGestureRecognizer(pinchGesture)
    }
    
    @objc
    private func startZooming(_ sender: UIPinchGestureRecognizer) {
      let scaleResult = sender.view?.transform.scaledBy(x: sender.scale, y: sender.scale)
      guard let scale = scaleResult, scale.a > 1, scale.d > 1 else { return }
       sender.view?.transform = scale
        sender.scale = 1;
        
    }
}
