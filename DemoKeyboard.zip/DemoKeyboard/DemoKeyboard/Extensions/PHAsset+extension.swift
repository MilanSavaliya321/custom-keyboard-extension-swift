//
//  PHAsset+extension.swift
//  CustomKeyboard
//
//  Created by Milan on 15/05/20.
//  Copyright © 2020 Milan. All rights reserved.
//

import Foundation
import  Photos
import  UIKit
extension PHAsset
{    
    func getAssetThumbnail() -> UIImage
    {
        
        let retinaScale = UIScreen.main.scale
       // let retinaSquare = CGSize(width: size * retinaScale, height: size * retinaScale);

        let cropSizeLength = min(self.pixelWidth, self.pixelHeight)
        let square = CGRect(x: 0, y: 0, width: CGFloat(cropSizeLength), height: CGFloat(cropSizeLength));
        let cropRect = square.applying(CGAffineTransform(scaleX: 1.0/CGFloat(self.pixelWidth), y: 1.0/CGFloat(self.pixelHeight)));
        
        let manager = PHImageManager.default();
        let options = PHImageRequestOptions();
        var thumbnail = UIImage()
        
        options.isSynchronous = true
        options.deliveryMode = .highQualityFormat
        options.resizeMode = .exact
        options.normalizedCropRect = cropRect
        
        manager.requestImage(for: self, targetSize: PHImageManagerMaximumSize, contentMode: .aspectFit, options: options, resultHandler: {(result, info)->Void in
            thumbnail = result!
        })
        return thumbnail
    }
}
